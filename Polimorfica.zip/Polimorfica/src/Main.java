abstract class Medico {
    protected String nome;

    public Medico(String nome) {
        this.nome = nome;
    }

    public abstract void consultar(Paciente paciente);
}

class MedicoCardiologista extends Medico {

    public MedicoCardiologista(String nome) {
        super(nome);
    }

    public void consultar(Paciente paciente) {
        System.out.println(nome + " está realizando uma consulta de cardiologia em " + paciente.getNome());
        System.out.println("Verificando pressão arterial e batimentos cardíacos...");
    }
}
class MedicoGinecologista extends Medico {

    public MedicoGinecologista(String nome) {
        super(nome);
    }
    public void consultar(Paciente paciente) {
        System.out.println(nome + " está realizando uma consulta ginecológica em " + paciente.getNome());
        System.out.println("Realizando exames ginecológicos e orientações sobre saúde reprodutiva...");
    }
}

class Paciente {
    private String nome;

    public Paciente(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}

public class Main {
    public static void main(String[] args) {
        Paciente paciente1 = new Paciente("João");
        Paciente paciente2 = new Paciente("Clara");

        Medico medico1 = new MedicoCardiologista("Dr. Carlos");
        Medico medico2 = new MedicoGinecologista("Dra. Ana");

        medico1.consultar(paciente1);
        medico2.consultar(paciente2);
    }
}
